create database futbolasir;

use futbolasir;

create table jugadores (
    id_jugador int primary key,
    nombre varchar(50),
    fecha_nac date,
    demarcacion varchar(50),
    internacional int,
    id_equipo int references equipo(id_equipo)

);

create table equipos (
    id_equipo int(2),
    nombre varchar(50),
    estadio varchar(50),
    aforo int(9),
    ano_fundacion int(4),
    ciudad varchar(50),
    primary key (id_equipo)
);

create table partidos (
    id_equipo_casa int references equipos,
    id_equipo_fuera int references equipos,
    fecha date,
    goles_casa int,
    goles_fuera int,
    observaciones varchar(100),
    primary key (id_equipo_casa,id_equipo_fuera)
);

create table goles (
    id_equipo_casa  int references partidos(id_equipo_casa),
    id_equipo_fuera int references partidos(id_equipo_fuera),
    minuto int,
    descripcion varchar(100),
    id_jugador int references jugadores(id_jugador)
);



insert into jugadores values (1,"Iker","1980-5-9","Portero",50,1);
insert into jugadores values (2,"Ronaldo","1974-7-7","Delantero",80,1);
insert into jugadores values (3,"Ramos","1998-9-9","Centrocampista",75,1);
insert into jugadores values (4,"Neymar","1999-3-3","Delantero",50,2);


insert into equipos(id_equipo,nombre,estadio,aforo,fundacion,ciudad) values (1,"Real Madrid","Santiago Bernabeu",80000,1950,"Madrid");
insert into equipos(id_equipo,nombre,estadio,aforo,fundacion,ciudad) values (2,"F.C Barcelona","Camp Nou",70000,1948,"Barcelona");
insert into equipos(id_equipo,nombre,estadio,aforo,fundacion,ciudad) values (3,"Valecnai C.F","Mestalla",90000,1952,"Valencia");
insert into equipos(id_equipo,nombre,estadio,aforo,fundacion,ciudad) values (4,"Atletico de Madrid","Vicente Calderon",55000,1945,"Madrid");


insert into partidos values (1,2,"2014-3-3",2,1,null,null);
insert into partidos values (1,3,"2014-4-4",3,1,null,null);
insert into partidos values (2,3,"2014-4-3",0,4,null,null);

insert into goles values(1,2,35,"De falta",2);
insert into goles values(1,2,70,null,2);
insert into goles values(1,2,88,null,4);
insert into goles values(1,3,5,null,3);
insert into goles values(1,3,10,"De penalti",2);








1
describe city;


2
select * from city;


3
select name,district from city;


4
select name from city where countrycode like "esp";

5
mysql> select name, countrycode from city order by 2 ;


6
select countrycode,count(countrycode),country.name from city,country where city.countrycode=country.code group by 1  order by 3 ;


7. 
select min(population) from city;

8. 
select max(population) from city;



