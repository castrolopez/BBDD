create database pruebas;

use pruebas;

create table profesor(
    dni varchar(9) primary key,
    nombre varchar (20),
    direccion varchar(30),
    telefono varchar(9)
);


create table modulo (
    codigo int primary key,
    nombre varchar(15)
);


create table cursa (
    codigo int references modulo(codigo),
    expediente int references alumno(expedeiente),
    primary key (codigo,expediente)
);

create table alumno (
    expediente int primary key,
    nombre varchar (20),
    apellidos varchar(30),
    fecha_nac date
);




1. 
2. create user profesor identified by "$Pepe1234$";

